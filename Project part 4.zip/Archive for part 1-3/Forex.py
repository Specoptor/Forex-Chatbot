# -*- coding: utf-8 -*-
"""
Created on Mon Mar  1 07:44:58 2021

@author: Faizan
"""
import datetime as dt
import requests
import json
import ForexSymbols as fs

def updateForexList():
    response=requests.get("https://fcsapi.com/api-v3/forex/list?type=forex&access_key=nSjVeSWxYCDrQhVQoqxzU")
    print(response.status_code)
    forexData=response.json()
    with open("forexData.txt", 'w') as file:
        json.dump(forexData, file)
    print(forexData)
    
    
def binaryForexConversion(currency_1, currency_2, amount=1, date=None):
        pair=currency_1+'/'+currency_2
        if fs.checkForexPair(pair) is not None:
            url="https://fcsapi.com/api-v3/forex/latest?symbol="
            accessKey="&access_key=nSjVeSWxYCDrQhVQoqxzU"
            api= url+pair+accessKey
            response=requests.get(api)
            print(response.status_code, ": Successfully retrieved conversion data")    
            print("Conversion as received: \n", response.content)
            print(type(response.content))
            print("\n payloadDict=response.json(): ")
            payloadDict=response.json()
            print(payloadDict)
            convertedAmount=float(payloadDict["response"][0]["c"])*amount
            return convertedAmount
        else: return ("Unable to find conversion rate for the given pair")
            #return in data['response'].:
            
print(x)