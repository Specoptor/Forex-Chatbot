import CYKParse
import Tree
import ForexSymbols as fs
requestInfo = {
        'currency_1': '',
        'currency_2': '',
        'amount': '',
        'date': ''
}
haveGreeted = False
amountInitialized=False
dateInitialized=False
currency_1_initialized=False
currency_2_initialized=False# Given the collection of parse trees returned by CYKParse, this function
# returns the one corresponding to the complete sentence.

def getSentenceParse(T):
    sentenceTrees = { k: v for k,v in T.items() if k.startswith('S/0') }
    completeSentenceTree = max(sentenceTrees.keys())
    print('getSentenceParse', completeSentenceTree)
    return T[completeSentenceTree]
# Processes the leaves of the parse tree to pull out the user's request.
def updateRequestInfo(Tr):
    
    global amountInitialized
    global dateInitialized
    global requestInfo
    global currency_1_initialized
    global currency_2_initialized
    setCurrency2=False
    
    for leaf in Tr.getLeaves():
        
        if leaf[0] == 'Amount': 
            requestInfo['amount'] = leaf[1] 
            amountInitialized=True
        
        elif setCurrency2 is False and leaf[0] == 'Forex':
            requestInfo['currency_1'] = leaf[1]
            setCurrency2=True
            currency_1_initialized=True
            
        elif leaf[0] == 'Forex' and setCurrency2:
            requestInfo['currency_2'] = leaf[1]      
            currency_2_initialized=True
        if leaf[0]=='Date':
            requestInfo['date'] = leaf[1]            
            dateInitialized=True
# This function contains the data known by our simple chatbot
#def performConversion(c1, c2, amount=1, date=None):
#    if location == 'Irvine':
#          if time == 'now' or time=='today': # today = now
#            return '68'
#          elif time == 'tomorrow':
#            return '70'
#          elif time=='yesterday': 
#            return '65'            
#          else: 
#            return 'unknown' 
#        #Added Tustin
#    elif location == 'Tustin':
#        if time == 'now' or time=='today': 
#            return '72'
#        elif time == 'tomorrow':
#            return '78'
#        elif time=='yesterday': # added yesterday
#            return '84' 
#        #Added Pasadena
#    elif location == 'Pasadena':
#        if time == 'now' or time=='today':
#            return '66'
#        elif time == 'tomorrow':
#            return '67'
#        elif time=='yesterday':
#           return '82' 
#    else:
#        return 'unknown'

# Format a reply to the user, based on what the user wrote.
def reply():
    global requestInfo
    global haveGreeted
    
    if not haveGreeted:
        print("Hello, what forex conversion query would you like to run?")
        haveGreeted = True
        
    if requestInfo['currency_1']=='' and requestInfo['currency_2']=='':
        print("Please select a pair of forex currencies from the list below for conversion")
        print(fs.forexPair)
    
    if currency_1_initialized and currency_2_initialized:           
            c1,c2= requestInfo['currency_1'], requestInfo['currency_2']
            amount=float(requestInfo['amount']) if amountInitialized else 1.0
            date=requestInfo['date'] if dateInitialized else None
            print(c1, c2, amount, date)
            conversion=fs.binaryForexConversion(c1, c2, amount, date)
            if date is None:
                print('The latest conversion data suggests that as of this moment {} {} in {} is {}'.format(amount, c1, c2, conversion))
            else: 
                print('The conversion rate of {} {} in {} was {} on {}'.format(amount, c1, c2, conversion, date))

# A simple hard-coded proof of concept.
def main():
    global requestInfo
    T, P = CYKParse.CYKParse(['what', 'is', 'GBP', 'to', 'BTC'], CYKParse.getGrammarWeather())
    sentenceTree=(getSentenceParse(T))
    updateRequestInfo(sentenceTree)
    reply()
    T, P = CYKParse.CYKParse(['how','much', 'is', '805.898', 'USD', 'in', 'PKR', 'on', '2020-08-01'], CYKParse.getGrammarWeather())
    sentenceTree=(getSentenceParse(T))
    updateRequestInfo(sentenceTree)
    reply()
    T, P = CYKParse.CYKParse(['what','is', 'the', 'worth', 'of', '94995.222', 'EUR', 'in', 'AUD', 'on', '1997-08-01'], CYKParse.getGrammarWeather())
    sentenceTree=(getSentenceParse(T))
    updateRequestInfo(sentenceTree)
    reply()
    T, P = CYKParse.CYKParse(['how','much', 'is', '805.898', 'USD', 'in', 'PKR', 'on', '2020-08-01'], CYKParse.getGrammarWeather())
    sentenceTree=(getSentenceParse(T))
    updateRequestInfo(sentenceTree)
    reply()
    T, P = CYKParse.CYKParse(['what','is', 'the', 'value','of', '999999999999', 'USD', 'in', 'BTC', 'on', '2020-08-01'], CYKParse.getGrammarWeather())
    sentenceTree=(getSentenceParse(T))
    updateRequestInfo(sentenceTree)
    reply()
    

#    T, P = CYKParse.CYKParse(['Will', 'today', 'be', 'hotter', 'than', 'yesterday', 'in', 'Irvine'], CYKParse.getGrammarWeather())
#    sentenceTree = getSentenceParse(T)
#    updateRequestInfo(sentenceTree)
#    reply()

main()