# -*- coding: utf-8 -*-
"""
Created on Mon Mar  1 20:47:51 2021

@author: Faizan
"""
import json
import requests
import datetime as dt

with open("forexData.txt", 'r') as file:
    data = json.load(file)

forexList=[]
forexPair=[]
for d in data['response']:
    forexPair.append(d['symbol'])
    forexList.extend(d['symbol'].split('/'))
    
forexSet=set(forexList)

def checkForexSymbol(word):
    return word in forexSet

def checkForexPair(word):
    return word in forexPair

def updateForexList():
    response=requests.get("https://fcsapi.com/api-v3/forex/list?type=forex&access_key=nSjVeSWxYCDrQhVQoqxzU")
    print(response.status_code)
    forexData=response.json()
    with open("forexData.txt", 'w') as file:
        json.dump(forexData, file)
    print(forexData)
    
def binaryForexConversion(currency_1, currency_2, amount=1, date=None):
    accessKey="&access_key=nSjVeSWxYCDrQhVQoqxzU"
    pair=currency_1+'/'+currency_2
    if date==None:
         url="https://fcsapi.com/api-v3/forex/latest?symbol="
         api=url+pair+"&candle=close"+accessKey
    else:
        url="https://fcsapi.com/api-v3/forex/history?symbol="
        dateInterval="&period=1d&from="+date+"T12:00&to="+(dt.date.today().isoformat())+"T12:00"           
        api= url+pair+dateInterval+"&candle=close"+accessKey
    response=requests.get(api)
    print(response.status_code, "****INFO*****:Successfully retrieved conversion data")    
    payloadDict=response.json()
    if date==None:
        convertedAmount=float((payloadDict["response"][0]["c"]))*amount
    else:
        key=list(payloadDict["response"].keys())[0]
        convertedAmount=float(payloadDict["response"].get(key)['c'])*amount

    return convertedAmount
            
    